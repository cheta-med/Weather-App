# Weather App

This is a simple weather app built with React that uses the Open-Meteo API to display current weather data for Delhi, India.

## Setup

1. Clone the repository
2. Run `npm install`
3. Start the app with `npm start`

## API

This app fetches weather from: https://open-meteo.com
